O arquivo '.ipynb' principal do trabalho encontra-se no seguinte diretório:

" ./code/TrabalhoPratico02_OcorrenciasAeronauticas.ipynb "

Já o arquivo '.pdf' referente ao mesmo encontra-se no diretório atual.
